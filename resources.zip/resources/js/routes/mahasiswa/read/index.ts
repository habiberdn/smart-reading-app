import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\MahasiswaController::progress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
export const progress = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: progress.url(args, options),
    method: 'post',
})

progress.definition = {
    methods: ["post"],
    url: '/mahasiswa/read/{assignment_id}/progress',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MahasiswaController::progress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
progress.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return progress.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::progress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
progress.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: progress.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::progress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
const progressForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: progress.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::progress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
progressForm.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: progress.url(args, options),
    method: 'post',
})

progress.form = progressForm

/**
* @see \App\Http\Controllers\MahasiswaController::finish
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
export const finish = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish.url(args, options),
    method: 'post',
})

finish.definition = {
    methods: ["post"],
    url: '/mahasiswa/read/{assignment_id}/finish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MahasiswaController::finish
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
finish.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return finish.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::finish
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
finish.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::finish
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
const finishForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: finish.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::finish
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
finishForm.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: finish.url(args, options),
    method: 'post',
})

finish.form = finishForm

const read = {
    progress: Object.assign(progress, progress),
    finish: Object.assign(finish, finish),
}

export default read