import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import classrooms386b8f from './classrooms'
import read from './read'
import target from './target'
import reminders from './reminders'
/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/mahasiswa/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\MahasiswaController::classrooms
* @see app/Http/Controllers/MahasiswaController.php:98
* @route '/mahasiswa/classrooms'
*/
export const classrooms = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classrooms.url(options),
    method: 'get',
})

classrooms.definition = {
    methods: ["get","head"],
    url: '/mahasiswa/classrooms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MahasiswaController::classrooms
* @see app/Http/Controllers/MahasiswaController.php:98
* @route '/mahasiswa/classrooms'
*/
classrooms.url = (options?: RouteQueryOptions) => {
    return classrooms.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::classrooms
* @see app/Http/Controllers/MahasiswaController.php:98
* @route '/mahasiswa/classrooms'
*/
classrooms.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classrooms.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::classrooms
* @see app/Http/Controllers/MahasiswaController.php:98
* @route '/mahasiswa/classrooms'
*/
classrooms.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: classrooms.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\MahasiswaController::classrooms
* @see app/Http/Controllers/MahasiswaController.php:98
* @route '/mahasiswa/classrooms'
*/
const classroomsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classrooms.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::classrooms
* @see app/Http/Controllers/MahasiswaController.php:98
* @route '/mahasiswa/classrooms'
*/
classroomsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classrooms.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::classrooms
* @see app/Http/Controllers/MahasiswaController.php:98
* @route '/mahasiswa/classrooms'
*/
classroomsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classrooms.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

classrooms.form = classroomsForm

const mahasiswa = {
    dashboard: Object.assign(dashboard, dashboard),
    classrooms: Object.assign(classrooms, classrooms386b8f),
    read: Object.assign(read, read),
    target: Object.assign(target, target),
    reminders: Object.assign(reminders, reminders),
}

export default mahasiswa