import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\MahasiswaController::join
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
export const join = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(options),
    method: 'post',
})

join.definition = {
    methods: ["post"],
    url: '/mahasiswa/classrooms/join',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MahasiswaController::join
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
join.url = (options?: RouteQueryOptions) => {
    return join.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::join
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
join.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::join
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
const joinForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: join.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::join
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
joinForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: join.url(options),
    method: 'post',
})

join.form = joinForm

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
export const show = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/mahasiswa/classrooms/{kode}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
show.url = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kode: args }
    }

    if (Array.isArray(args)) {
        args = {
            kode: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kode: args.kode,
    }

    return show.definition.url
            .replace('{kode}', parsedArgs.kode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
show.get = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
show.head = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
const showForm = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
showForm.get = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
showForm.head = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

const classrooms = {
    show: Object.assign(show, show),
}

export default classrooms