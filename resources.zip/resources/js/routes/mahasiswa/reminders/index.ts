import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\FeedbackController::readAll
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
export const readAll = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: readAll.url(options),
    method: 'put',
})

readAll.definition = {
    methods: ["put"],
    url: '/mahasiswa/reminders/read-all',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FeedbackController::readAll
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
readAll.url = (options?: RouteQueryOptions) => {
    return readAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FeedbackController::readAll
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
readAll.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: readAll.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FeedbackController::readAll
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
const readAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: readAll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FeedbackController::readAll
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
readAllForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: readAll.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

readAll.form = readAllForm

/**
* @see \App\Http\Controllers\FeedbackController::read
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
export const read = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: read.url(args, options),
    method: 'put',
})

read.definition = {
    methods: ["put"],
    url: '/mahasiswa/reminders/{feedback}/read',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FeedbackController::read
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
read.url = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { feedback: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { feedback: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            feedback: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        feedback: typeof args.feedback === 'object'
        ? args.feedback.id
        : args.feedback,
    }

    return read.definition.url
            .replace('{feedback}', parsedArgs.feedback.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FeedbackController::read
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
read.put = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: read.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FeedbackController::read
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
const readForm = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: read.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FeedbackController::read
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
readForm.put = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: read.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

read.form = readForm

const reminders = {
    readAll: Object.assign(readAll, readAll),
    read: Object.assign(read, read),
}

export default reminders