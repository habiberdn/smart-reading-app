import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import quiz from './quiz'
import summary from './summary'
/**
* @see \App\Http\Controllers\AssessmentController::data
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
export const data = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(args, options),
    method: 'get',
})

data.definition = {
    methods: ["get","head"],
    url: '/read/{assignment_id}/assessment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssessmentController::data
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
data.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return data.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::data
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
data.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::data
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
data.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AssessmentController::data
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
const dataForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: data.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::data
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
dataForm.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: data.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::data
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
dataForm.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: data.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

data.form = dataForm

const assessment = {
    data: Object.assign(data, data),
    quiz: Object.assign(quiz, quiz),
    summary: Object.assign(summary, summary),
}

export default assessment