import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\AssessmentController::submit
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
export const submit = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/read/{assignment_id}/quiz/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AssessmentController::submit
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
submit.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return submit.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::submit
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
submit.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::submit
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
const submitForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::submit
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
submitForm.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submit.url(args, options),
    method: 'post',
})

submit.form = submitForm

const quiz = {
    submit: Object.assign(submit, submit),
}

export default quiz