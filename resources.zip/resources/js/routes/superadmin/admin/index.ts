import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::index
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:13
* @route '/superadmin/admin'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/superadmin/admin',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::index
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:13
* @route '/superadmin/admin'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::index
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:13
* @route '/superadmin/admin'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::index
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:13
* @route '/superadmin/admin'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::index
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:13
* @route '/superadmin/admin'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::index
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:13
* @route '/superadmin/admin'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::index
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:13
* @route '/superadmin/admin'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::store
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:24
* @route '/superadmin/admin'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/superadmin/admin',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::store
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:24
* @route '/superadmin/admin'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::store
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:24
* @route '/superadmin/admin'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::store
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:24
* @route '/superadmin/admin'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::store
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:24
* @route '/superadmin/admin'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::update
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:44
* @route '/superadmin/admin/{user}'
*/
export const update = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/superadmin/admin/{user}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::update
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:44
* @route '/superadmin/admin/{user}'
*/
update.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return update.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::update
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:44
* @route '/superadmin/admin/{user}'
*/
update.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::update
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:44
* @route '/superadmin/admin/{user}'
*/
const updateForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::update
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:44
* @route '/superadmin/admin/{user}'
*/
updateForm.put = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::destroy
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:72
* @route '/superadmin/admin/{user}'
*/
export const destroy = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/superadmin/admin/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::destroy
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:72
* @route '/superadmin/admin/{user}'
*/
destroy.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { user: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            user: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        user: typeof args.user === 'object'
        ? args.user.id
        : args.user,
    }

    return destroy.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::destroy
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:72
* @route '/superadmin/admin/{user}'
*/
destroy.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::destroy
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:72
* @route '/superadmin/admin/{user}'
*/
const destroyForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Superadmin\SuperadminAdminController::destroy
* @see app/Http/Controllers/Superadmin/SuperadminAdminController.php:72
* @route '/superadmin/admin/{user}'
*/
destroyForm.delete = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const admin = {
    index: Object.assign(index, index),
    store: Object.assign(store, store),
    update: Object.assign(update, update),
    destroy: Object.assign(destroy, destroy),
}

export default admin