import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
export const accept = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accept.url(options),
    method: 'get',
})

accept.definition = {
    methods: ["get","head"],
    url: '/invitation/accept',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
accept.url = (options?: RouteQueryOptions) => {
    return accept.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
accept.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accept.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
accept.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: accept.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
const acceptForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: accept.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
acceptForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: accept.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
acceptForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: accept.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

accept.form = acceptForm

const invitation = {
    accept: Object.assign(accept, accept),
}

export default invitation