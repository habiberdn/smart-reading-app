import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\ReadingController::workspace
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
export const workspace = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspace.url(args, options),
    method: 'get',
})

workspace.definition = {
    methods: ["get","head"],
    url: '/read/{assignment_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReadingController::workspace
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
workspace.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return workspace.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReadingController::workspace
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
workspace.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspace.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::workspace
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
workspace.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workspace.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReadingController::workspace
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
const workspaceForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: workspace.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::workspace
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
workspaceForm.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: workspace.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::workspace
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
workspaceForm.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: workspace.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

workspace.form = workspaceForm

/**
* @see \App\Http\Controllers\ReadingController::file
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
export const file = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: file.url(args, options),
    method: 'get',
})

file.definition = {
    methods: ["get","head"],
    url: '/read/{assignment_id}/file',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReadingController::file
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
file.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return file.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReadingController::file
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
file.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: file.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::file
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
file.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: file.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReadingController::file
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
const fileForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: file.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::file
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
fileForm.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: file.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::file
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
fileForm.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: file.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

file.form = fileForm

const reading = {
    workspace: Object.assign(workspace, workspace),
    file: Object.assign(file, file),
}

export default reading