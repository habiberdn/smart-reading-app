import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReadingController::regenerate
* @see app/Http/Controllers/ReadingController.php:149
* @route '/dosen/assignments/{id}/glossary/regenerate'
*/
export const regenerate = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

regenerate.definition = {
    methods: ["post"],
    url: '/dosen/assignments/{id}/glossary/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReadingController::regenerate
* @see app/Http/Controllers/ReadingController.php:149
* @route '/dosen/assignments/{id}/glossary/regenerate'
*/
regenerate.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return regenerate.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReadingController::regenerate
* @see app/Http/Controllers/ReadingController.php:149
* @route '/dosen/assignments/{id}/glossary/regenerate'
*/
regenerate.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ReadingController::regenerate
* @see app/Http/Controllers/ReadingController.php:149
* @route '/dosen/assignments/{id}/glossary/regenerate'
*/
const regenerateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: regenerate.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ReadingController::regenerate
* @see app/Http/Controllers/ReadingController.php:149
* @route '/dosen/assignments/{id}/glossary/regenerate'
*/
regenerateForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: regenerate.url(args, options),
    method: 'post',
})

regenerate.form = regenerateForm

const glossary = {
    regenerate: Object.assign(regenerate, regenerate),
}

export default glossary