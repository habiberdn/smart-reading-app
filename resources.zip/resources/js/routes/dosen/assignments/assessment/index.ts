import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AssessmentController::recap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
export const recap = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recap.url(args, options),
    method: 'get',
})

recap.definition = {
    methods: ["get","head"],
    url: '/dosen/assignments/{id}/assessment-recap',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssessmentController::recap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
recap.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return recap.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::recap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
recap.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: recap.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::recap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
recap.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: recap.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AssessmentController::recap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
const recapForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recap.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::recap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
recapForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recap.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::recap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
recapForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: recap.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

recap.form = recapForm

const assessment = {
    recap: Object.assign(recap, recap),
}

export default assessment