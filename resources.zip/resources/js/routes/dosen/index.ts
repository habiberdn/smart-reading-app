import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import classrooms386b8f from './classrooms'
import assignments from './assignments'
import quiz from './quiz'
/**
* @see \App\Http\Controllers\DosenController::dashboard
* @see app/Http/Controllers/DosenController.php:10
* @route '/dosen/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/dosen/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\DosenController::dashboard
* @see app/Http/Controllers/DosenController.php:10
* @route '/dosen/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\DosenController::dashboard
* @see app/Http/Controllers/DosenController.php:10
* @route '/dosen/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DosenController::dashboard
* @see app/Http/Controllers/DosenController.php:10
* @route '/dosen/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\DosenController::dashboard
* @see app/Http/Controllers/DosenController.php:10
* @route '/dosen/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DosenController::dashboard
* @see app/Http/Controllers/DosenController.php:10
* @route '/dosen/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\DosenController::dashboard
* @see app/Http/Controllers/DosenController.php:10
* @route '/dosen/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\ClassroomController::classDetails
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
export const classDetails = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classDetails.url(args, options),
    method: 'get',
})

classDetails.definition = {
    methods: ["get","head"],
    url: '/dosen/classrooms/{kode}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClassroomController::classDetails
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
classDetails.url = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kode: args }
    }

    if (Array.isArray(args)) {
        args = {
            kode: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kode: args.kode,
    }

    return classDetails.definition.url
            .replace('{kode}', parsedArgs.kode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClassroomController::classDetails
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
classDetails.get = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classDetails.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::classDetails
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
classDetails.head = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: classDetails.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ClassroomController::classDetails
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
const classDetailsForm = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classDetails.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::classDetails
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
classDetailsForm.get = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classDetails.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::classDetails
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
classDetailsForm.head = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classDetails.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

classDetails.form = classDetailsForm

/**
* @see \App\Http\Controllers\ClassroomController::classrooms
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
export const classrooms = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classrooms.url(options),
    method: 'get',
})

classrooms.definition = {
    methods: ["get","head"],
    url: '/dosen/classrooms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClassroomController::classrooms
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
classrooms.url = (options?: RouteQueryOptions) => {
    return classrooms.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClassroomController::classrooms
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
classrooms.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classrooms.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::classrooms
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
classrooms.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: classrooms.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ClassroomController::classrooms
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
const classroomsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classrooms.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::classrooms
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
classroomsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classrooms.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::classrooms
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
classroomsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classrooms.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

classrooms.form = classroomsForm

const dosen = {
    dashboard: Object.assign(dashboard, dashboard),
    classDetails: Object.assign(classDetails, classDetails),
    classrooms: Object.assign(classrooms, classrooms386b8f),
    assignments: Object.assign(assignments, assignments),
    quiz: Object.assign(quiz, quiz),
}

export default dosen