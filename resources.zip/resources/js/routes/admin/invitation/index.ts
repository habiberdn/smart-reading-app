import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\InvitationController::generate
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/admin/invitation/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\InvitationController::generate
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InvitationController::generate
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InvitationController::generate
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generate.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InvitationController::generate
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generate.url(options),
    method: 'post',
})

generate.form = generateForm

const invitation = {
    generate: Object.assign(generate, generate),
}

export default invitation