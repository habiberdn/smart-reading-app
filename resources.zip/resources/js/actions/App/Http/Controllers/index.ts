import AuthenticatedSessionController from './AuthenticatedSessionController'
import ReadingController from './ReadingController'
import MahasiswaController from './MahasiswaController'
import DosenController from './DosenController'
import ClassroomController from './ClassroomController'
import ReadingAssignmentController from './ReadingAssignmentController'
import Admin from './Admin'
import Superadmin from './Superadmin'
import GoogleAuthController from './GoogleAuthController'
import Settings from './Settings'

const Controllers = {
    AuthenticatedSessionController: Object.assign(AuthenticatedSessionController, AuthenticatedSessionController),
    ReadingController: Object.assign(ReadingController, ReadingController),
    MahasiswaController: Object.assign(MahasiswaController, MahasiswaController),
    DosenController: Object.assign(DosenController, DosenController),
    ClassroomController: Object.assign(ClassroomController, ClassroomController),
    ReadingAssignmentController: Object.assign(ReadingAssignmentController, ReadingAssignmentController),
    Admin: Object.assign(Admin, Admin),
    Superadmin: Object.assign(Superadmin, Superadmin),
    GoogleAuthController: Object.assign(GoogleAuthController, GoogleAuthController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers