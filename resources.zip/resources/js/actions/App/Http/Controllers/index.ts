import AuthenticatedSessionController from './AuthenticatedSessionController'
import ReadingController from './ReadingController'
import AssessmentController from './AssessmentController'
import MahasiswaController from './MahasiswaController'
import DosenController from './DosenController'
import ClassroomController from './ClassroomController'
import ReadingAssignmentController from './ReadingAssignmentController'
import ReadingTargetController from './ReadingTargetController'
import FeedbackController from './FeedbackController'
import Admin from './Admin'
import Superadmin from './Superadmin'
import GoogleAuthController from './GoogleAuthController'
import Settings from './Settings'

const Controllers = {
    AuthenticatedSessionController: Object.assign(AuthenticatedSessionController, AuthenticatedSessionController),
    ReadingController: Object.assign(ReadingController, ReadingController),
    AssessmentController: Object.assign(AssessmentController, AssessmentController),
    MahasiswaController: Object.assign(MahasiswaController, MahasiswaController),
    DosenController: Object.assign(DosenController, DosenController),
    ClassroomController: Object.assign(ClassroomController, ClassroomController),
    ReadingAssignmentController: Object.assign(ReadingAssignmentController, ReadingAssignmentController),
    ReadingTargetController: Object.assign(ReadingTargetController, ReadingTargetController),
    FeedbackController: Object.assign(FeedbackController, FeedbackController),
    Admin: Object.assign(Admin, Admin),
    Superadmin: Object.assign(Superadmin, Superadmin),
    GoogleAuthController: Object.assign(GoogleAuthController, GoogleAuthController),
    Settings: Object.assign(Settings, Settings),
}

export default Controllers