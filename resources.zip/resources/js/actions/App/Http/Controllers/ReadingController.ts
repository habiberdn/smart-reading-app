import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReadingController::show
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
export const show = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/read/{assignment_id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReadingController::show
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
show.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return show.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReadingController::show
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
show.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::show
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
show.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReadingController::show
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
const showForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::show
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
showForm.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::show
* @see app/Http/Controllers/ReadingController.php:44
* @route '/read/{assignment_id}'
*/
showForm.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\ReadingController::streamFile
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
export const streamFile = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: streamFile.url(args, options),
    method: 'get',
})

streamFile.definition = {
    methods: ["get","head"],
    url: '/read/{assignment_id}/file',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReadingController::streamFile
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
streamFile.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return streamFile.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReadingController::streamFile
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
streamFile.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: streamFile.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::streamFile
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
streamFile.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: streamFile.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReadingController::streamFile
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
const streamFileForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: streamFile.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::streamFile
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
streamFileForm.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: streamFile.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingController::streamFile
* @see app/Http/Controllers/ReadingController.php:12
* @route '/read/{assignment_id}/file'
*/
streamFileForm.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: streamFile.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

streamFile.form = streamFileForm

const ReadingController = { show, streamFile }

export default ReadingController