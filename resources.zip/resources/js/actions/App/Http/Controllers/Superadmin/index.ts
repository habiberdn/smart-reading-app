import SuperadminDashboardController from './SuperadminDashboardController'
import SuperadminAdminController from './SuperadminAdminController'

const Superadmin = {
    SuperadminDashboardController: Object.assign(SuperadminDashboardController, SuperadminDashboardController),
    SuperadminAdminController: Object.assign(SuperadminAdminController, SuperadminAdminController),
}

export default Superadmin