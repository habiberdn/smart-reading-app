import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReadingAssignmentController::store
* @see app/Http/Controllers/ReadingAssignmentController.php:16
* @route '/dosen/classrooms/{kode}/assignments'
*/
export const store = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dosen/classrooms/{kode}/assignments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ReadingAssignmentController::store
* @see app/Http/Controllers/ReadingAssignmentController.php:16
* @route '/dosen/classrooms/{kode}/assignments'
*/
store.url = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kode: args }
    }

    if (Array.isArray(args)) {
        args = {
            kode: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kode: args.kode,
    }

    return store.definition.url
            .replace('{kode}', parsedArgs.kode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReadingAssignmentController::store
* @see app/Http/Controllers/ReadingAssignmentController.php:16
* @route '/dosen/classrooms/{kode}/assignments'
*/
store.post = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ReadingAssignmentController::store
* @see app/Http/Controllers/ReadingAssignmentController.php:16
* @route '/dosen/classrooms/{kode}/assignments'
*/
const storeForm = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ReadingAssignmentController::store
* @see app/Http/Controllers/ReadingAssignmentController.php:16
* @route '/dosen/classrooms/{kode}/assignments'
*/
storeForm.post = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(args, options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\ReadingAssignmentController::destroy
* @see app/Http/Controllers/ReadingAssignmentController.php:88
* @route '/dosen/assignments/{id}'
*/
export const destroy = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/dosen/assignments/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ReadingAssignmentController::destroy
* @see app/Http/Controllers/ReadingAssignmentController.php:88
* @route '/dosen/assignments/{id}'
*/
destroy.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroy.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReadingAssignmentController::destroy
* @see app/Http/Controllers/ReadingAssignmentController.php:88
* @route '/dosen/assignments/{id}'
*/
destroy.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ReadingAssignmentController::destroy
* @see app/Http/Controllers/ReadingAssignmentController.php:88
* @route '/dosen/assignments/{id}'
*/
const destroyForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ReadingAssignmentController::destroy
* @see app/Http/Controllers/ReadingAssignmentController.php:88
* @route '/dosen/assignments/{id}'
*/
destroyForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const ReadingAssignmentController = { store, destroy }

export default ReadingAssignmentController