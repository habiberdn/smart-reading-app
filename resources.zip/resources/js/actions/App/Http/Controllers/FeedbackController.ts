import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\FeedbackController::markAllRead
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
export const markAllRead = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: markAllRead.url(options),
    method: 'put',
})

markAllRead.definition = {
    methods: ["put"],
    url: '/mahasiswa/reminders/read-all',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FeedbackController::markAllRead
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
markAllRead.url = (options?: RouteQueryOptions) => {
    return markAllRead.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\FeedbackController::markAllRead
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
markAllRead.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: markAllRead.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FeedbackController::markAllRead
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
const markAllReadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAllRead.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FeedbackController::markAllRead
* @see app/Http/Controllers/FeedbackController.php:36
* @route '/mahasiswa/reminders/read-all'
*/
markAllReadForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markAllRead.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

markAllRead.form = markAllReadForm

/**
* @see \App\Http\Controllers\FeedbackController::markRead
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
export const markRead = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: markRead.url(args, options),
    method: 'put',
})

markRead.definition = {
    methods: ["put"],
    url: '/mahasiswa/reminders/{feedback}/read',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\FeedbackController::markRead
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
markRead.url = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { feedback: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { feedback: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            feedback: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        feedback: typeof args.feedback === 'object'
        ? args.feedback.id
        : args.feedback,
    }

    return markRead.definition.url
            .replace('{feedback}', parsedArgs.feedback.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\FeedbackController::markRead
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
markRead.put = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: markRead.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\FeedbackController::markRead
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
const markReadForm = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markRead.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\FeedbackController::markRead
* @see app/Http/Controllers/FeedbackController.php:15
* @route '/mahasiswa/reminders/{feedback}/read'
*/
markReadForm.put = (args: { feedback: number | { id: number } } | [feedback: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: markRead.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

markRead.form = markReadForm

const FeedbackController = { markAllRead, markRead }

export default FeedbackController