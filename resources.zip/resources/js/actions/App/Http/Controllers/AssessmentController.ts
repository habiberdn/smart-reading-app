import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentData
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
export const getAssessmentData = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAssessmentData.url(args, options),
    method: 'get',
})

getAssessmentData.definition = {
    methods: ["get","head"],
    url: '/read/{assignment_id}/assessment',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentData
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
getAssessmentData.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return getAssessmentData.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentData
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
getAssessmentData.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAssessmentData.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentData
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
getAssessmentData.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAssessmentData.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentData
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
const getAssessmentDataForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAssessmentData.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentData
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
getAssessmentDataForm.get = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAssessmentData.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentData
* @see app/Http/Controllers/AssessmentController.php:19
* @route '/read/{assignment_id}/assessment'
*/
getAssessmentDataForm.head = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAssessmentData.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getAssessmentData.form = getAssessmentDataForm

/**
* @see \App\Http\Controllers\AssessmentController::submitQuiz
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
export const submitQuiz = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitQuiz.url(args, options),
    method: 'post',
})

submitQuiz.definition = {
    methods: ["post"],
    url: '/read/{assignment_id}/quiz/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AssessmentController::submitQuiz
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
submitQuiz.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return submitQuiz.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::submitQuiz
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
submitQuiz.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitQuiz.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::submitQuiz
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
const submitQuizForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitQuiz.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::submitQuiz
* @see app/Http/Controllers/AssessmentController.php:66
* @route '/read/{assignment_id}/quiz/submit'
*/
submitQuizForm.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitQuiz.url(args, options),
    method: 'post',
})

submitQuiz.form = submitQuizForm

/**
* @see \App\Http\Controllers\AssessmentController::submitSummary
* @see app/Http/Controllers/AssessmentController.php:132
* @route '/read/{assignment_id}/summary/submit'
*/
export const submitSummary = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitSummary.url(args, options),
    method: 'post',
})

submitSummary.definition = {
    methods: ["post"],
    url: '/read/{assignment_id}/summary/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AssessmentController::submitSummary
* @see app/Http/Controllers/AssessmentController.php:132
* @route '/read/{assignment_id}/summary/submit'
*/
submitSummary.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return submitSummary.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::submitSummary
* @see app/Http/Controllers/AssessmentController.php:132
* @route '/read/{assignment_id}/summary/submit'
*/
submitSummary.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitSummary.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::submitSummary
* @see app/Http/Controllers/AssessmentController.php:132
* @route '/read/{assignment_id}/summary/submit'
*/
const submitSummaryForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitSummary.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::submitSummary
* @see app/Http/Controllers/AssessmentController.php:132
* @route '/read/{assignment_id}/summary/submit'
*/
submitSummaryForm.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: submitSummary.url(args, options),
    method: 'post',
})

submitSummary.form = submitSummaryForm

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentRecap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
export const getAssessmentRecap = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAssessmentRecap.url(args, options),
    method: 'get',
})

getAssessmentRecap.definition = {
    methods: ["get","head"],
    url: '/dosen/assignments/{id}/assessment-recap',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentRecap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
getAssessmentRecap.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return getAssessmentRecap.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentRecap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
getAssessmentRecap.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAssessmentRecap.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentRecap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
getAssessmentRecap.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAssessmentRecap.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentRecap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
const getAssessmentRecapForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAssessmentRecap.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentRecap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
getAssessmentRecapForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAssessmentRecap.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\AssessmentController::getAssessmentRecap
* @see app/Http/Controllers/AssessmentController.php:267
* @route '/dosen/assignments/{id}/assessment-recap'
*/
getAssessmentRecapForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: getAssessmentRecap.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

getAssessmentRecap.form = getAssessmentRecapForm

/**
* @see \App\Http\Controllers\AssessmentController::regenerateQuiz
* @see app/Http/Controllers/AssessmentController.php:156
* @route '/dosen/assignments/{id}/quiz/regenerate'
*/
export const regenerateQuiz = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateQuiz.url(args, options),
    method: 'post',
})

regenerateQuiz.definition = {
    methods: ["post"],
    url: '/dosen/assignments/{id}/quiz/regenerate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AssessmentController::regenerateQuiz
* @see app/Http/Controllers/AssessmentController.php:156
* @route '/dosen/assignments/{id}/quiz/regenerate'
*/
regenerateQuiz.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return regenerateQuiz.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::regenerateQuiz
* @see app/Http/Controllers/AssessmentController.php:156
* @route '/dosen/assignments/{id}/quiz/regenerate'
*/
regenerateQuiz.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: regenerateQuiz.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::regenerateQuiz
* @see app/Http/Controllers/AssessmentController.php:156
* @route '/dosen/assignments/{id}/quiz/regenerate'
*/
const regenerateQuizForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: regenerateQuiz.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::regenerateQuiz
* @see app/Http/Controllers/AssessmentController.php:156
* @route '/dosen/assignments/{id}/quiz/regenerate'
*/
regenerateQuizForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: regenerateQuiz.url(args, options),
    method: 'post',
})

regenerateQuiz.form = regenerateQuizForm

/**
* @see \App\Http\Controllers\AssessmentController::storeQuestion
* @see app/Http/Controllers/AssessmentController.php:178
* @route '/dosen/assignments/{id}/quiz/questions'
*/
export const storeQuestion = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeQuestion.url(args, options),
    method: 'post',
})

storeQuestion.definition = {
    methods: ["post"],
    url: '/dosen/assignments/{id}/quiz/questions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AssessmentController::storeQuestion
* @see app/Http/Controllers/AssessmentController.php:178
* @route '/dosen/assignments/{id}/quiz/questions'
*/
storeQuestion.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return storeQuestion.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::storeQuestion
* @see app/Http/Controllers/AssessmentController.php:178
* @route '/dosen/assignments/{id}/quiz/questions'
*/
storeQuestion.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeQuestion.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::storeQuestion
* @see app/Http/Controllers/AssessmentController.php:178
* @route '/dosen/assignments/{id}/quiz/questions'
*/
const storeQuestionForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeQuestion.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::storeQuestion
* @see app/Http/Controllers/AssessmentController.php:178
* @route '/dosen/assignments/{id}/quiz/questions'
*/
storeQuestionForm.post = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: storeQuestion.url(args, options),
    method: 'post',
})

storeQuestion.form = storeQuestionForm

/**
* @see \App\Http\Controllers\AssessmentController::updateQuestion
* @see app/Http/Controllers/AssessmentController.php:216
* @route '/dosen/quiz/questions/{id}'
*/
export const updateQuestion = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateQuestion.url(args, options),
    method: 'put',
})

updateQuestion.definition = {
    methods: ["put"],
    url: '/dosen/quiz/questions/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\AssessmentController::updateQuestion
* @see app/Http/Controllers/AssessmentController.php:216
* @route '/dosen/quiz/questions/{id}'
*/
updateQuestion.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return updateQuestion.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::updateQuestion
* @see app/Http/Controllers/AssessmentController.php:216
* @route '/dosen/quiz/questions/{id}'
*/
updateQuestion.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateQuestion.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\AssessmentController::updateQuestion
* @see app/Http/Controllers/AssessmentController.php:216
* @route '/dosen/quiz/questions/{id}'
*/
const updateQuestionForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateQuestion.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::updateQuestion
* @see app/Http/Controllers/AssessmentController.php:216
* @route '/dosen/quiz/questions/{id}'
*/
updateQuestionForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: updateQuestion.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

updateQuestion.form = updateQuestionForm

/**
* @see \App\Http\Controllers\AssessmentController::destroyQuestion
* @see app/Http/Controllers/AssessmentController.php:248
* @route '/dosen/quiz/questions/{id}'
*/
export const destroyQuestion = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyQuestion.url(args, options),
    method: 'delete',
})

destroyQuestion.definition = {
    methods: ["delete"],
    url: '/dosen/quiz/questions/{id}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\AssessmentController::destroyQuestion
* @see app/Http/Controllers/AssessmentController.php:248
* @route '/dosen/quiz/questions/{id}'
*/
destroyQuestion.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    if (Array.isArray(args)) {
        args = {
            id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        id: args.id,
    }

    return destroyQuestion.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssessmentController::destroyQuestion
* @see app/Http/Controllers/AssessmentController.php:248
* @route '/dosen/quiz/questions/{id}'
*/
destroyQuestion.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyQuestion.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\AssessmentController::destroyQuestion
* @see app/Http/Controllers/AssessmentController.php:248
* @route '/dosen/quiz/questions/{id}'
*/
const destroyQuestionForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyQuestion.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\AssessmentController::destroyQuestion
* @see app/Http/Controllers/AssessmentController.php:248
* @route '/dosen/quiz/questions/{id}'
*/
destroyQuestionForm.delete = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroyQuestion.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroyQuestion.form = destroyQuestionForm

const AssessmentController = { getAssessmentData, submitQuiz, submitSummary, getAssessmentRecap, regenerateQuiz, storeQuestion, updateQuestion, destroyQuestion }

export default AssessmentController