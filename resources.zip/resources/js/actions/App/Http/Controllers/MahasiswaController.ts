import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MahasiswaController::assignmentsList
* @see app/Http/Controllers/MahasiswaController.php:261
* @route '/assignments'
*/
export const assignmentsList = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assignmentsList.url(options),
    method: 'get',
})

assignmentsList.definition = {
    methods: ["get","head"],
    url: '/assignments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MahasiswaController::assignmentsList
* @see app/Http/Controllers/MahasiswaController.php:261
* @route '/assignments'
*/
assignmentsList.url = (options?: RouteQueryOptions) => {
    return assignmentsList.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::assignmentsList
* @see app/Http/Controllers/MahasiswaController.php:261
* @route '/assignments'
*/
assignmentsList.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assignmentsList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::assignmentsList
* @see app/Http/Controllers/MahasiswaController.php:261
* @route '/assignments'
*/
assignmentsList.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: assignmentsList.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\MahasiswaController::assignmentsList
* @see app/Http/Controllers/MahasiswaController.php:261
* @route '/assignments'
*/
const assignmentsListForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: assignmentsList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::assignmentsList
* @see app/Http/Controllers/MahasiswaController.php:261
* @route '/assignments'
*/
assignmentsListForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: assignmentsList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::assignmentsList
* @see app/Http/Controllers/MahasiswaController.php:261
* @route '/assignments'
*/
assignmentsListForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: assignmentsList.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

assignmentsList.form = assignmentsListForm

/**
* @see \App\Http\Controllers\MahasiswaController::exploreList
* @see app/Http/Controllers/MahasiswaController.php:282
* @route '/explore'
*/
export const exploreList = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exploreList.url(options),
    method: 'get',
})

exploreList.definition = {
    methods: ["get","head"],
    url: '/explore',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MahasiswaController::exploreList
* @see app/Http/Controllers/MahasiswaController.php:282
* @route '/explore'
*/
exploreList.url = (options?: RouteQueryOptions) => {
    return exploreList.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::exploreList
* @see app/Http/Controllers/MahasiswaController.php:282
* @route '/explore'
*/
exploreList.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exploreList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::exploreList
* @see app/Http/Controllers/MahasiswaController.php:282
* @route '/explore'
*/
exploreList.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exploreList.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\MahasiswaController::exploreList
* @see app/Http/Controllers/MahasiswaController.php:282
* @route '/explore'
*/
const exploreListForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exploreList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::exploreList
* @see app/Http/Controllers/MahasiswaController.php:282
* @route '/explore'
*/
exploreListForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exploreList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::exploreList
* @see app/Http/Controllers/MahasiswaController.php:282
* @route '/explore'
*/
exploreListForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: exploreList.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

exploreList.form = exploreListForm

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/mahasiswa/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::dashboard
* @see app/Http/Controllers/MahasiswaController.php:16
* @route '/mahasiswa/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm

/**
* @see \App\Http\Controllers\MahasiswaController::joinClass
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
export const joinClass = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: joinClass.url(options),
    method: 'post',
})

joinClass.definition = {
    methods: ["post"],
    url: '/mahasiswa/classrooms/join',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MahasiswaController::joinClass
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
joinClass.url = (options?: RouteQueryOptions) => {
    return joinClass.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::joinClass
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
joinClass.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: joinClass.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::joinClass
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
const joinClassForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: joinClass.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::joinClass
* @see app/Http/Controllers/MahasiswaController.php:94
* @route '/mahasiswa/classrooms/join'
*/
joinClassForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: joinClass.url(options),
    method: 'post',
})

joinClass.form = joinClassForm

/**
* @see \App\Http\Controllers\MahasiswaController::saveProgress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
export const saveProgress = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveProgress.url(args, options),
    method: 'post',
})

saveProgress.definition = {
    methods: ["post"],
    url: '/mahasiswa/read/{assignment_id}/progress',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MahasiswaController::saveProgress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
saveProgress.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return saveProgress.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::saveProgress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
saveProgress.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveProgress.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::saveProgress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
const saveProgressForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveProgress.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::saveProgress
* @see app/Http/Controllers/MahasiswaController.php:118
* @route '/mahasiswa/read/{assignment_id}/progress'
*/
saveProgressForm.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: saveProgress.url(args, options),
    method: 'post',
})

saveProgress.form = saveProgressForm

/**
* @see \App\Http\Controllers\MahasiswaController::finishReading
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
export const finishReading = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finishReading.url(args, options),
    method: 'post',
})

finishReading.definition = {
    methods: ["post"],
    url: '/mahasiswa/read/{assignment_id}/finish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MahasiswaController::finishReading
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
finishReading.url = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { assignment_id: args }
    }

    if (Array.isArray(args)) {
        args = {
            assignment_id: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        assignment_id: args.assignment_id,
    }

    return finishReading.definition.url
            .replace('{assignment_id}', parsedArgs.assignment_id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::finishReading
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
finishReading.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finishReading.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::finishReading
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
const finishReadingForm = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: finishReading.url(args, options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\MahasiswaController::finishReading
* @see app/Http/Controllers/MahasiswaController.php:190
* @route '/mahasiswa/read/{assignment_id}/finish'
*/
finishReadingForm.post = (args: { assignment_id: string | number } | [assignment_id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: finishReading.url(args, options),
    method: 'post',
})

finishReading.form = finishReadingForm

/**
* @see \App\Http\Controllers\MahasiswaController::classroomsList
* @see app/Http/Controllers/MahasiswaController.php:80
* @route '/mahasiswa/classrooms'
*/
export const classroomsList = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classroomsList.url(options),
    method: 'get',
})

classroomsList.definition = {
    methods: ["get","head"],
    url: '/mahasiswa/classrooms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MahasiswaController::classroomsList
* @see app/Http/Controllers/MahasiswaController.php:80
* @route '/mahasiswa/classrooms'
*/
classroomsList.url = (options?: RouteQueryOptions) => {
    return classroomsList.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MahasiswaController::classroomsList
* @see app/Http/Controllers/MahasiswaController.php:80
* @route '/mahasiswa/classrooms'
*/
classroomsList.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: classroomsList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::classroomsList
* @see app/Http/Controllers/MahasiswaController.php:80
* @route '/mahasiswa/classrooms'
*/
classroomsList.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: classroomsList.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\MahasiswaController::classroomsList
* @see app/Http/Controllers/MahasiswaController.php:80
* @route '/mahasiswa/classrooms'
*/
const classroomsListForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classroomsList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::classroomsList
* @see app/Http/Controllers/MahasiswaController.php:80
* @route '/mahasiswa/classrooms'
*/
classroomsListForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classroomsList.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\MahasiswaController::classroomsList
* @see app/Http/Controllers/MahasiswaController.php:80
* @route '/mahasiswa/classrooms'
*/
classroomsListForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: classroomsList.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

classroomsList.form = classroomsListForm

const MahasiswaController = { assignmentsList, exploreList, dashboard, joinClass, saveProgress, finishReading, classroomsList }

export default MahasiswaController