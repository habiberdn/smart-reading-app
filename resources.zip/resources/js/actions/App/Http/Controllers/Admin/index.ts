import AdminDashboardController from './AdminDashboardController'
import AdminDosenController from './AdminDosenController'
import InvitationController from './InvitationController'

const Admin = {
    AdminDashboardController: Object.assign(AdminDashboardController, AdminDashboardController),
    AdminDosenController: Object.assign(AdminDosenController, AdminDosenController),
    InvitationController: Object.assign(InvitationController, InvitationController),
}

export default Admin