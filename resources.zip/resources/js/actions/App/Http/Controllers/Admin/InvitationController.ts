import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\InvitationController::generateLink
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
export const generateLink = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateLink.url(options),
    method: 'post',
})

generateLink.definition = {
    methods: ["post"],
    url: '/admin/invitation/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\InvitationController::generateLink
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
generateLink.url = (options?: RouteQueryOptions) => {
    return generateLink.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\InvitationController::generateLink
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
generateLink.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateLink.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InvitationController::generateLink
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
const generateLinkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generateLink.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\Admin\InvitationController::generateLink
* @see app/Http/Controllers/Admin/InvitationController.php:15
* @route '/admin/invitation/generate'
*/
generateLinkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: generateLink.url(options),
    method: 'post',
})

generateLink.form = generateLinkForm

const InvitationController = { generateLink }

export default InvitationController