import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
export const accept = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accept.url(options),
    method: 'get',
})

accept.definition = {
    methods: ["get","head"],
    url: '/invitation/accept',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
accept.url = (options?: RouteQueryOptions) => {
    return accept.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
accept.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accept.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
accept.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: accept.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
const acceptForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: accept.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
acceptForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: accept.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::accept
* @see app/Http/Controllers/GoogleAuthController.php:18
* @route '/invitation/accept'
*/
acceptForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: accept.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

accept.form = acceptForm

/**
* @see \App\Http\Controllers\GoogleAuthController::redirect
* @see app/Http/Controllers/GoogleAuthController.php:33
* @route '/auth/google/redirect'
*/
export const redirect = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(options),
    method: 'get',
})

redirect.definition = {
    methods: ["get","head"],
    url: '/auth/google/redirect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GoogleAuthController::redirect
* @see app/Http/Controllers/GoogleAuthController.php:33
* @route '/auth/google/redirect'
*/
redirect.url = (options?: RouteQueryOptions) => {
    return redirect.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GoogleAuthController::redirect
* @see app/Http/Controllers/GoogleAuthController.php:33
* @route '/auth/google/redirect'
*/
redirect.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::redirect
* @see app/Http/Controllers/GoogleAuthController.php:33
* @route '/auth/google/redirect'
*/
redirect.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirect.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::redirect
* @see app/Http/Controllers/GoogleAuthController.php:33
* @route '/auth/google/redirect'
*/
const redirectForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::redirect
* @see app/Http/Controllers/GoogleAuthController.php:33
* @route '/auth/google/redirect'
*/
redirectForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirect.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::redirect
* @see app/Http/Controllers/GoogleAuthController.php:33
* @route '/auth/google/redirect'
*/
redirectForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: redirect.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

redirect.form = redirectForm

/**
* @see \App\Http\Controllers\GoogleAuthController::callback
* @see app/Http/Controllers/GoogleAuthController.php:44
* @route '/api/auth/callback/google'
*/
export const callback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

callback.definition = {
    methods: ["get","head"],
    url: '/api/auth/callback/google',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\GoogleAuthController::callback
* @see app/Http/Controllers/GoogleAuthController.php:44
* @route '/api/auth/callback/google'
*/
callback.url = (options?: RouteQueryOptions) => {
    return callback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\GoogleAuthController::callback
* @see app/Http/Controllers/GoogleAuthController.php:44
* @route '/api/auth/callback/google'
*/
callback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::callback
* @see app/Http/Controllers/GoogleAuthController.php:44
* @route '/api/auth/callback/google'
*/
callback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: callback.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::callback
* @see app/Http/Controllers/GoogleAuthController.php:44
* @route '/api/auth/callback/google'
*/
const callbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::callback
* @see app/Http/Controllers/GoogleAuthController.php:44
* @route '/api/auth/callback/google'
*/
callbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\GoogleAuthController::callback
* @see app/Http/Controllers/GoogleAuthController.php:44
* @route '/api/auth/callback/google'
*/
callbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: callback.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

callback.form = callbackForm

const GoogleAuthController = { accept, redirect, callback }

export default GoogleAuthController