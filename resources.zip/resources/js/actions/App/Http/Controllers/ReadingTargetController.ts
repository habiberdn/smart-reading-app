import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReadingTargetController::show
* @see app/Http/Controllers/ReadingTargetController.php:15
* @route '/mahasiswa/target'
*/
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/mahasiswa/target',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReadingTargetController::show
* @see app/Http/Controllers/ReadingTargetController.php:15
* @route '/mahasiswa/target'
*/
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReadingTargetController::show
* @see app/Http/Controllers/ReadingTargetController.php:15
* @route '/mahasiswa/target'
*/
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingTargetController::show
* @see app/Http/Controllers/ReadingTargetController.php:15
* @route '/mahasiswa/target'
*/
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ReadingTargetController::show
* @see app/Http/Controllers/ReadingTargetController.php:15
* @route '/mahasiswa/target'
*/
const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingTargetController::show
* @see app/Http/Controllers/ReadingTargetController.php:15
* @route '/mahasiswa/target'
*/
showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ReadingTargetController::show
* @see app/Http/Controllers/ReadingTargetController.php:15
* @route '/mahasiswa/target'
*/
showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show.form = showForm

/**
* @see \App\Http\Controllers\ReadingTargetController::update
* @see app/Http/Controllers/ReadingTargetController.php:34
* @route '/mahasiswa/target'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/mahasiswa/target',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ReadingTargetController::update
* @see app/Http/Controllers/ReadingTargetController.php:34
* @route '/mahasiswa/target'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReadingTargetController::update
* @see app/Http/Controllers/ReadingTargetController.php:34
* @route '/mahasiswa/target'
*/
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ReadingTargetController::update
* @see app/Http/Controllers/ReadingTargetController.php:34
* @route '/mahasiswa/target'
*/
const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ReadingTargetController::update
* @see app/Http/Controllers/ReadingTargetController.php:34
* @route '/mahasiswa/target'
*/
updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

const ReadingTargetController = { show, update }

export default ReadingTargetController