import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
const show9f290573d377b2aa306f058476b4b15a = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show9f290573d377b2aa306f058476b4b15a.url(args, options),
    method: 'get',
})

show9f290573d377b2aa306f058476b4b15a.definition = {
    methods: ["get","head"],
    url: '/dosen/classrooms/{kode}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
show9f290573d377b2aa306f058476b4b15a.url = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kode: args }
    }

    if (Array.isArray(args)) {
        args = {
            kode: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kode: args.kode,
    }

    return show9f290573d377b2aa306f058476b4b15a.definition.url
            .replace('{kode}', parsedArgs.kode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
show9f290573d377b2aa306f058476b4b15a.get = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show9f290573d377b2aa306f058476b4b15a.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
show9f290573d377b2aa306f058476b4b15a.head = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show9f290573d377b2aa306f058476b4b15a.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
const show9f290573d377b2aa306f058476b4b15aForm = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show9f290573d377b2aa306f058476b4b15a.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
show9f290573d377b2aa306f058476b4b15aForm.get = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show9f290573d377b2aa306f058476b4b15a.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/dosen/classrooms/{kode}'
*/
show9f290573d377b2aa306f058476b4b15aForm.head = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show9f290573d377b2aa306f058476b4b15a.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show9f290573d377b2aa306f058476b4b15a.form = show9f290573d377b2aa306f058476b4b15aForm
/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
const show4c389e129985138de09327936d83e84b = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show4c389e129985138de09327936d83e84b.url(args, options),
    method: 'get',
})

show4c389e129985138de09327936d83e84b.definition = {
    methods: ["get","head"],
    url: '/mahasiswa/classrooms/{kode}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
show4c389e129985138de09327936d83e84b.url = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kode: args }
    }

    if (Array.isArray(args)) {
        args = {
            kode: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kode: args.kode,
    }

    return show4c389e129985138de09327936d83e84b.definition.url
            .replace('{kode}', parsedArgs.kode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
show4c389e129985138de09327936d83e84b.get = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show4c389e129985138de09327936d83e84b.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
show4c389e129985138de09327936d83e84b.head = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show4c389e129985138de09327936d83e84b.url(args, options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
const show4c389e129985138de09327936d83e84bForm = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show4c389e129985138de09327936d83e84b.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
show4c389e129985138de09327936d83e84bForm.get = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show4c389e129985138de09327936d83e84b.url(args, options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::show
* @see app/Http/Controllers/ClassroomController.php:53
* @route '/mahasiswa/classrooms/{kode}'
*/
show4c389e129985138de09327936d83e84bForm.head = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: show4c389e129985138de09327936d83e84b.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

show4c389e129985138de09327936d83e84b.form = show4c389e129985138de09327936d83e84bForm

/**
* Multiple routes resolve to \App\Http\Controllers\ClassroomController::show, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `show['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const show = {
    '/dosen/classrooms/{kode}': show9f290573d377b2aa306f058476b4b15a,
    '/mahasiswa/classrooms/{kode}': show4c389e129985138de09327936d83e84b,
}

/**
* @see \App\Http\Controllers\ClassroomController::index
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dosen/classrooms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClassroomController::index
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClassroomController::index
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::index
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \App\Http\Controllers\ClassroomController::index
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::index
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url(options),
    method: 'get',
})

/**
* @see \App\Http\Controllers\ClassroomController::index
* @see app/Http/Controllers/ClassroomController.php:15
* @route '/dosen/classrooms'
*/
indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: index.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

index.form = indexForm

/**
* @see \App\Http\Controllers\ClassroomController::store
* @see app/Http/Controllers/ClassroomController.php:31
* @route '/dosen/classrooms'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dosen/classrooms',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClassroomController::store
* @see app/Http/Controllers/ClassroomController.php:31
* @route '/dosen/classrooms'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClassroomController::store
* @see app/Http/Controllers/ClassroomController.php:31
* @route '/dosen/classrooms'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ClassroomController::store
* @see app/Http/Controllers/ClassroomController.php:31
* @route '/dosen/classrooms'
*/
const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ClassroomController::store
* @see app/Http/Controllers/ClassroomController.php:31
* @route '/dosen/classrooms'
*/
storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: store.url(options),
    method: 'post',
})

store.form = storeForm

/**
* @see \App\Http\Controllers\ClassroomController::update
* @see app/Http/Controllers/ClassroomController.php:197
* @route '/dosen/classrooms/{kode}'
*/
export const update = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/dosen/classrooms/{kode}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClassroomController::update
* @see app/Http/Controllers/ClassroomController.php:197
* @route '/dosen/classrooms/{kode}'
*/
update.url = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kode: args }
    }

    if (Array.isArray(args)) {
        args = {
            kode: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kode: args.kode,
    }

    return update.definition.url
            .replace('{kode}', parsedArgs.kode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClassroomController::update
* @see app/Http/Controllers/ClassroomController.php:197
* @route '/dosen/classrooms/{kode}'
*/
update.put = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

/**
* @see \App\Http\Controllers\ClassroomController::update
* @see app/Http/Controllers/ClassroomController.php:197
* @route '/dosen/classrooms/{kode}'
*/
const updateForm = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ClassroomController::update
* @see app/Http/Controllers/ClassroomController.php:197
* @route '/dosen/classrooms/{kode}'
*/
updateForm.put = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: update.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'PUT',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

update.form = updateForm

/**
* @see \App\Http\Controllers\ClassroomController::destroy
* @see app/Http/Controllers/ClassroomController.php:220
* @route '/dosen/classrooms/{kode}'
*/
export const destroy = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/dosen/classrooms/{kode}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClassroomController::destroy
* @see app/Http/Controllers/ClassroomController.php:220
* @route '/dosen/classrooms/{kode}'
*/
destroy.url = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { kode: args }
    }

    if (Array.isArray(args)) {
        args = {
            kode: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        kode: args.kode,
    }

    return destroy.definition.url
            .replace('{kode}', parsedArgs.kode.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClassroomController::destroy
* @see app/Http/Controllers/ClassroomController.php:220
* @route '/dosen/classrooms/{kode}'
*/
destroy.delete = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \App\Http\Controllers\ClassroomController::destroy
* @see app/Http/Controllers/ClassroomController.php:220
* @route '/dosen/classrooms/{kode}'
*/
const destroyForm = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

/**
* @see \App\Http\Controllers\ClassroomController::destroy
* @see app/Http/Controllers/ClassroomController.php:220
* @route '/dosen/classrooms/{kode}'
*/
destroyForm.delete = (args: { kode: string | number } | [kode: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: destroy.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'DELETE',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'post',
})

destroy.form = destroyForm

const ClassroomController = { show, index, store, update, destroy }

export default ClassroomController