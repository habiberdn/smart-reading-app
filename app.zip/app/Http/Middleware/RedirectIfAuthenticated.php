<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class RedirectIfAuthenticated
{
    public function handle(Request $request, Closure $next, string ...$guards): Response
    {
        $guards = empty($guards) ? [null] : $guards;

        foreach ($guards as $guard) {
            if (Auth::guard($guard)->check()) {
                $user = Auth::user();

                $redirectTo = match ($user->role) {
                    'superadmin' => '/superadmin/dashboard',
                    'admin' => '/admin/dashboard',
                    'dosen' => '/dosen/dashboard',
                    'mahasiswa' => '/mahasiswa/dashboard',
                    default => '/dashboard',
                };

                return redirect($redirectTo);
            }
        }

        return $next($request);
    }
}
