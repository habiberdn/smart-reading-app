<?php

namespace App\Actions\Fortify;

use App\Concerns\PasswordValidationRules;
use App\Concerns\ProfileValidationRules;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
use Laravel\Fortify\Contracts\CreatesNewUsers;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules, ProfileValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array<string, string>  $input
     */
    public function create(array $input): User
    {
        Validator::make($input, [
            'username' => ['required', 'string', 'max:255', 'unique:users,username'],
            'name'     => $this->nameRules(),
            'nim'      => ['nullable', 'string', 'max:50'],
            'password' => $this->passwordRules(),
        ])->validate();

        return User::create([
            'name'     => $input['name'],
            'username' => $input['username'],
            'nim'      => $input['nim'] ?? null,
            'password' => $input['password'],
            'role'     => 'mahasiswa',
        ]);
    }
}
